#if ! defined( VTM_VERSION )
#define VTM_VERSION "7.0"
#endif
